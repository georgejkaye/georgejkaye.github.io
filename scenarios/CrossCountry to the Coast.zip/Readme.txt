GJK Scenarios - CrossCountry to the Coast

Today you are driving the 1V41 0642 Birmingham New Street to Paignton Virgin CrossCountry service, for the last leg from Exeter St Davids to Paignton. Traction is in the form of a Class 390 Pendolino. It is a lovely spring morning so it should be a good drive! You will be stopping at Newton Abbot, Torquay and finally Paignton.

This scenario uses the lovely Riviera Line Electrified by joethefish! I decided to go along with his story, so the CrossCountry franchise is now owned by Virgin again, who use Pendolinos across their network. GWR continue to operate the Greater Western franchise, and now operate a 4tph stopping service between Paignton and Exmouth (using the Class 365), in addition to 2tph fast services between Penzance and Paddington (using the Class 800). Freight operations are handled by DRS, who use their extensive fleet of Class 68s across the country.

Requirements can be found at http://www.georgejkaye.com/trains/crosscountry-to-the-coast

=== How to install ===

1) Extract the rwp file somewhere handy (like your Desktop)
2) Navigate to your Train Simulator directory (often at C:/Program Files (x86)/Steam/steamapps/common/RailWorks)
3) Open Utilities.exe
4) Click on the 'Package Manager' tab
5) Click Install
6) Navigate to where you extracted the rwp file and select it
7) Open Train Simulator and enjoy!

=== License ===

Feel free to mess around with this scenario and do whatever you want with it! Just remember to link back to my site if you use it so that others can enjoy it too!