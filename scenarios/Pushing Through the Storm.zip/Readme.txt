GJK Scenarios - Pushing Through the Storm

Hello driver! Your final task of the day is to drive the 1A15 Gatwick Express service to London Victoria, leaving Brighton at 19:48. You will be calling at Gatwick Airport and London Victoria only. Watch out though, as the weather is positively foul and could impede your progress towards the capital. We are also receiving reports that the train ahead of us has been experiencing engine troubles. Allow passengers to board and set up your cab ready for departure at 19:48!

Another busy scenario ending up in south London, but not everything may go to plan! Set in 2017, so Gatwick Express are now using 387s, Thameslink have replaced First Capital Connect, and Southern have ditched all their Class 456s. The timetable is based on the current working timetable.

I would strongly recommend reducing your graphics settings for this scenario, as there are places that are extremely intensive and the game may crash!

Requirements can be found at http://www.georgejkaye.com/trains/pushing-through-the-storm

=== How to install ===

1) Extract the rwp file somewhere handy (like your Desktop)
2) Navigate to your Train Simulator directory (often at C:/Program Files (x86)/Steam/steamapps/common/RailWorks)
3) Open Utilities.exe
4) Click on the 'Package Manager' tab
5) Click Install
6) Navigate to where you extracted the rwp file and select it
7) Open Train Simulator and enjoy!

=== License ===

Feel free to mess around with this scenario and do whatever you want with it! Just remember to link back to my site if you use it so that others can enjoy it too!