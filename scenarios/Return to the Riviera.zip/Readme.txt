GJK Scenarios - Return to the Riviera

Although the age is diesel is but a distant memory, the Intercity 125 ‘High Speed Train’ is still fondly regarded by many railway enthusiasts. Fortunately, GWR have arranged a special railtour using one of their old HSTs and have chosen you to have the honour of driving this very special journey! You will be calling at Exeter St Davids, Dawlish, Teignmouth, Newton Abbot, Torquay and Paignton.

This scenario uses the lovely Riviera Line Electrified by joethefish! I decided to go along with his story, so the CrossCountry franchise is now owned by Virgin again, who use Pendolinos across their network. GWR continue to operate the Greater Western franchise, and now operate a 4tph stopping service between Paignton and Exmouth (using the Class 365), in addition to 2tph fast services between Penzance and Paddington (using the Class 800). Freight operations are handled by DRS, who use their extensive fleet of Class 68s across the country.

Requirements can be found at http://www.georgejkaye.com/trains/return-to-the-riviera

=== How to install ===

1) Extract the rwp file somewhere handy (like your Desktop)
2) Navigate to your Train Simulator directory (often at C:/Program Files (x86)/Steam/steamapps/common/RailWorks)
3) Open Utilities.exe
4) Click on the 'Package Manager' tab
5) Click Install
6) Navigate to where you extracted the rwp file and select it
7) Open Train Simulator and enjoy!

=== License ===

Feel free to mess around with this scenario and do whatever you want with it! Just remember to link back to my site if you use it so that others can enjoy it too!