function OnEvent(event)
    if(event == "cabcam") then
        SysCall("CameraManager:ActivateCamera", "CabCamera", 0);
    end
end

function TestCondition(condition)
end