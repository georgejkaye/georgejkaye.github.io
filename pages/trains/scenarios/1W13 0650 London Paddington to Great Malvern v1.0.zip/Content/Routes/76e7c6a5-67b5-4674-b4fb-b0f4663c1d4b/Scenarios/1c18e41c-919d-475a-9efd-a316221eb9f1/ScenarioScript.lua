-- true/false defn
FALSE = 0
TRUE = 1

-- condition return values
CONDITION_NOT_YET_MET = 0
CONDITION_SUCCEEDED = 1
CONDITION_FAILED = 2

-- Message types
MT_INFO = 0   -- large centre screen pop up
MT_ALERT = 1  -- top right alert message

MSG_TOP = 1
MSG_VCENTRE = 2
MSG_BOTTOM = 4
MSG_LEFT = 8
MSG_CENTRE = 16
MSG_RIGHT = 32

MSG_SMALL = 0
MSG_REG = 1
MSG_LRG = 2

function OnEvent(event)
    return _G["OnEvent" .. event]();
end

function TestCondition(condition)
    return _G["TestCondition" .. event]();
end

function OnEventCabCam()
    SysCall("CameraManager:ActivateCamera", "CabCamera", 0);
end

function OnEventIntroMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Hello driver!", "intromessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventEndingMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Well done!", "endmessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventSingleWeather1()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "SingleWeather1" )
    return TRUE;
end

function OnEventSingleWeather2()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "SingleWeather2" )
    return TRUE;
end

function OnEventSingleWeather3()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "SingleWeather3" )
    return TRUE;
end

function OnEventSingleWeather4()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "SingleWeather4" )
    return TRUE;
end

function OnEventSingleWeather5()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "SingleWeather5" )
    return TRUE;
end

function OnEventSingleWeather6()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "SingleWeather6" )
    return TRUE;
end

function OnEventWeather1()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "Weather1" )
    return TRUE;
end

function OnEventWeather2()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "Weather2" )
    return TRUE;
end

function OnEventWeather3()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "Weather3" )
    return TRUE;
end

function OnEventDrizzleFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "DrizzleFog" )
    return TRUE;
end

function OnEventLightRain()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "LightRain" )
    return TRUE;
end

function OnEventLightRainFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "LightRainFog" )
    return TRUE;
end
    
function OnEventModRain()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ModRain" )
    return TRUE;
end

function OnEventModRainFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ModRainFog" )
    return TRUE;
end

function OnEventHeavyRain()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "HeavyRain" )
    return TRUE;
end

function OnEventHeavyRainFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "HeavyRainFog" )
    return TRUE;
end

function OnEventLightSnow()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "LightSnow" )
    return TRUE;
end

function OnEventLightSnowFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "LightSnowFog" )
    return TRUE;
end
    
function OnEventModSnow()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ModSnow" )
    return TRUE;
end

function OnEventModSnowFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ModSnowFog" )
    return TRUE;
end

function OnEventHeavySnow()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "HeavySnow" )
    return TRUE;
end

function OnEventHeavySnowFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "HeavySnowFog" )
    return TRUE;
end

function OnEventClearLightFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ClearLightFog" )
    return TRUE;
end

function OnEventClearMedFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ClearMedFog" )
    return TRUE;
end

function OnEventClearThickFog()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ClearThickFog" )
    return TRUE;
end

function OnEventLightFogClear()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "LightFogClear" )
    return TRUE;
end

function OnEventMedFogClear()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "MedFogClear" )
    return TRUE;
end

function OnEventThickFogClear()
    SysCall ( "WeatherController:SetCurrentWeatherEventChain", "ThickFogClear" )
    return TRUE;
end