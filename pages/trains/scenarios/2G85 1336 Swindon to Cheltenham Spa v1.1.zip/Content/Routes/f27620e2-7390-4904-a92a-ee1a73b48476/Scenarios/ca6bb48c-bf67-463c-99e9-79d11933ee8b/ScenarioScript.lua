-- true/false defn
FALSE = 0
TRUE = 1

-- condition return values
CONDITION_NOT_YET_MET = 0
CONDITION_SUCCEEDED = 1
CONDITION_FAILED = 2

-- Message types
MT_INFO = 0   -- large centre screen pop up
MT_ALERT = 1  -- top right alert message

MSG_TOP = 1
MSG_VCENTRE = 2
MSG_BOTTOM = 4
MSG_LEFT = 8
MSG_CENTRE = 16
MSG_RIGHT = 32

MSG_SMALL = 0
MSG_REG = 1
MSG_LRG = 2

function OnEvent(event)
    return _G["OnEvent" .. event]();
end

function TestCondition(condition)
    return _G["TestCondition" .. event]();
end

function OnEventCabCam()
    SysCall("CameraManager:ActivateCamera", "CabCamera", 0);
end

function OnEventIntroMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Hello driver!", "intromessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventArrGloucesterMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Message", "arrgloucestermessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventDepGloucesterMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Message", "depgloucestermessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventDepGloucesterMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Message", "depgloucestermessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventTempSpeedMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Message", "speedmessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end

function OnEventEndingMessage()
    SysCall("ScenarioManager:ShowInfoMessageExt", "Well done!", "endmessage.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE);
end